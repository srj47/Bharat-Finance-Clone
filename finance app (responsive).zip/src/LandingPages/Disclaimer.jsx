import React from "react";

import "./CSS/homePage.css";
import { HeaderCard } from "./Cards";
import Navbar, { MainNavbar } from "./Navbar";

const Disclaimer = () => {
  return (
    <>
      <Navbar />
      <MainNavbar />
      <div>
        <HeaderCard header="Disclaimer" path="HOME  > DISCLAIMER" />

        <div className="header_title">
          <h1>Disclaimer for AID MEDIA PVT. LTD.</h1>
          <p className="fs-4">
            If you require any more information or have any questions about our
            site's disclaimer, please feel free to contact us by email at
            support@aidmedia.in. Our Disclaimer was generated with the help of
            the
            <a
              href="https://www.termsfeed.com/disclaimer-generator/"
              className="text-primary mx-2"
            >
              Free Disclaimer Generator
            </a>
            .
          </p>
        </div>
        <div className="t_c_para">
          <div className="circles_div wrk_prog_circle">
            <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles circle_middel"></div>
            <div className="circles"></div>
            <div className="circles"></div>
          </div>
          <div className="row">
            <div className="col-sm-12"></div>
            <div className="row">
              <div className="col-sm-12">
                <h1 className="fs-1 fw-3" style={{ color: "#201630" }}>
                  Disclaimers for AID MEDIA
                </h1>
                <p className="fs-4">
                  All the information on this website -
                  https://bharatfinance.site/ - is published in good faith and
                  for general information purpose only. AID MEDIA does not make
                  any warranties about the completeness, reliability and
                  accuracy of this information. Any action you take upon the
                  information you find on this website (AID MEDIA ), is strictly
                  at your own risk. AID MEDIA will not be liable for any losses
                  and/or damages in connection with the use of our website.
                </p>
                <p className="fs-4">
                  From our website, you can visit other websites by following
                  hyperlinks to such external sites. While we strive to provide
                  only quality links to useful and ethical websites, we have no
                  control over the content and nature of these sites. These
                  links to other websites do not imply a recommendation for all
                  the content found on these sites. Site owners and content may
                  change without notice and may occur before we have the
                  opportunity to remove a link which may have gone 'bad'.
                </p>
                <p className="fs-4">
                  Please be also aware that when you leave our website, other
                  sites may have different privacy policies and terms which are
                  beyond our control. Please be sure to check the Privacy
                  Policies of these sites as well as their "Terms of Service"
                  before engaging in any business or uploading any information.
                </p>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12">
                <h1 className="fs-1 fw-3" style={{ color: "#201630" }}>
                  Consent
                </h1>
                <p className="fs-4">
                  By using our website, you hereby consent to our disclaimer and
                  agree to its terms.
                </p>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12">
                <h1 className="fs-1 fw-3" style={{ color: "#201630" }}>
                  Update
                </h1>
                <p className="fs-4">
                  Should we update, amend or make any changes to this document,
                  those changes will be prominently posted here.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Disclaimer;
